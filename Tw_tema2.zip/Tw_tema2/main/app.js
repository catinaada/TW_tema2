function addTokens(input, tokens){

if(typeof input != 'string'){
    throw new Error ('Invalid input');
}

if(input.length<6){
    throw new Error('Input should have at least 6 characters');
}

if(Array.isArray(tokens) )
for(let i=0;i<tokens.length;i++){
  {  if(!(tokens[i].tokenName && typeof tokens[i].tokenName==='string'))
    throw new Error ('Invalid array format');

    if(tokens[i].hasOwnProperty('tokenName')==false || Object.keys(tokens[i]).length != 1){
      throw new Error ('Invalid array format');
    }
  }
}

if(input.includes("...")==false) 
       return 'Inputs';
else{
    for(let i=0;i<tokens.length;i++){
        return input.replace('...','${'+tokens[i].tokenName+'}');
    }
  }
}


const app = {
    addTokens: addTokens
}

module.exports = app;